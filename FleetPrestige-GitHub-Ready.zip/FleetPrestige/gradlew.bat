@echo off
set GRADLE_VERSION=8.6
set GRADLE_HOME=%USERPROFILE%\.gradle\wrapper\dists\gradle-%GRADLE_VERSION%-bin\gradle-%GRADLE_VERSION%
if not exist "%GRADLE_HOME%in\gradle.bat" (
    echo Downloading Gradle %GRADLE_VERSION%...
    powershell -Command "Invoke-WebRequest -Uri https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip -OutFile gradle.zip; Expand-Archive gradle.zip -DestinationPath %USERPROFILE%\.gradle\wrapper\dists\gradle-%GRADLE_VERSION%-bin; Remove-Item gradle.zip"
)
"%GRADLE_HOME%in\gradle.bat" %*
